#!/usr/bin/python3
# -*- coding:utf-8 -*-
# __author__ = '__Jack__'

from django.apps import AppConfig


class ArticlesConfig(AppConfig):
    name = 'zanhu.articles'
    verbose_name = '文章'
