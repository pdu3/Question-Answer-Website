#!/usr/bin/python3
# -*- coding:utf-8 -*-
# __author__ = '__Jack__'

from django.apps import AppConfig


class QaConfig(AppConfig):
    name = 'zanhu.qa'
    verbose_name = '问答'
